package DuckBehaviour;

public interface FlyBehaviour {
    public void fly();
}